# surrealdb-wasm

SurrealDB's WebAssembly browser engine, vendored from
[surrealdb.js](https://github.com/surrealdb/surrealdb.js) `packages/wasm` (3.0.4,
bundling surrealdb-core 3.0.5), with one local patch that makes it actually run
in a browser.

## Why this is not just the npm package

`@surrealdb/wasm` on npm is broken, and has been for every published 3.x
release. Two separate bugs:

1. **`indxdb://` throws `idb error` on `db.use()`.** IndexedDB auto-commits a
   transaction whenever the event loop goes idle, and every Rust `.await` yields
   to the event loop — so the second request in a multi-step write lands on a
   closed transaction. Fixed upstream in `indxdb` 0.12.0, which buffers writes
   and flushes them in one batch ([indxdb#7](https://github.com/surrealdb/indxdb/pull/7),
   [surrealdb.js#571](https://github.com/surrealdb/surrealdb.js/issues/571)).
   That landed two days after the last npm publish, so **no released build
   contains it**. Building from this package's `Cargo.lock` does.

2. **Every engine panics ~1s after connect**, `mem://` included:
   `time not implemented on this platform`, surfacing in the browser as
   `RuntimeError: unreachable`. surrealdb-core declares the `wasmtimer` shim and
   uses it in its three `sleep` helpers, but the datastore, executor and exec
   layers still import `tokio::time` un-cfg'd. On wasm32 those resolve to real
   tokio, whose clock bottoms out in `std::time`. `Datastore::retry` runs during
   open, so the engine dies before you can use it.
   ([surrealdb#6711](https://github.com/surrealdb/surrealdb/issues/6711) — still
   open upstream.)

Bug 2 is what `patches/surrealdb-core-3.0.5-wasm-timers.patch` fixes.

## The patch

`[patch.crates-io]` in `Cargo.toml` points surrealdb-core at
`vendor/surrealdb-core` — the published crate with the patch applied. Only the
patch is source; `vendor/` is a build input, regenerated from crates.io and
**not committed**.

The patch routes the wasm-reachable timer sites through `wasmtimer`, following
the idiom already used in these same files for `spawn`:

```rust
#[cfg(not(target_family = "wasm"))]
use tokio::time::sleep;
#[cfg(target_family = "wasm")]
use wasmtimer::tokio::sleep;
```

Eight files: `kvs/{ds,index,sequences,tasklease}.rs`, `dbs/executor.rs`,
`exec/operators/timeout.rs`, `exec/function/builtin/sleep.rs`,
`expr/statements/sleep.rs`.

Two things worth knowing if you touch it:

- `Instant` lives at **`wasmtimer::std::Instant`**, not `wasmtimer::tokio`.
  (Issue #6711's suggested snippet gets this wrong and will not compile.)
  Where the file already imports `web_time::Instant` for wall-clock reads, use
  that instead — it is what the surrounding code does.
- `dbs/executor.rs` needs two extra adjustments beyond a plain alias swap:
  `timeout` is imported **aliased** because both call sites bind a local
  `Duration` named `timeout` that would shadow it, and the query-timeout guard
  is split per-target because wasm has no tokio runtime to spawn onto and no
  `JoinHandle` to abort.

## Building

Prerequisites:

- `rustup target add wasm32-unknown-unknown`
- `cargo install wasm-bindgen-cli --version 0.2.108 --locked` — the version must
  match the `wasm-bindgen` crate in `Cargo.lock` exactly or bindgen refuses
- `wasm-opt` comes from the `binaryen` devDependency, so run through the package
  script rather than calling `build.ts` directly

```bash
bun run build
```

`build.ts` regenerates `vendor/` first if it is missing, so a fresh clone works
without a separate step. To force it: `bun run vendor`.

The build is deterministic — rebuilding from a clean `vendor/` reproduces the
committed `wasm/` and `dist/` byte for byte.

### `bun run build` exits 1 even on success

The last step (`dts-bundle-generator`) fails with a **pre-existing upstream type
error**, unrelated to the patch:

```
src-ts/engine.ts(49,5): error TS4094: Property '#private' of exported anonymous
class type may not be private or protected.
```

It runs *after* the wasm binary and both `dist/*.mjs` bundles are written, so
the runtime artifacts are complete and correct. `dist/surrealdb-wasm.d.ts` is
committed and stale-but-valid. Do not "fix" this by reverting the patch — check
the artifact timestamps instead.

### Committed artifacts

`wasm/` and `dist/` are committed (upstream's layout does this, and `package.json`
`files` ships them). Consumers do not need a Rust toolchain. Rebuild and commit
them together whenever the patch or `Cargo.lock` changes.

## Bumping surrealdb-core

Upstream keeps *adding* un-cfg'd `tokio::time` imports — 3.0.5 has five in
`src/`, 3.2.4 has nine — so the patch will not apply cleanly across versions.

1. Change `VERSION` in `vendor.ts` and rename the patch to match.
2. `bun run vendor` and fix rejected hunks.
3. Audit for new sites. Every `tokio::time` / `std::time::Instant` reference in
   `src/` must be under `#[cfg(not(target_family = "wasm"))]`, inside
   `#[cfg(test)]`, or in a non-wasm backend (`rocksdb`/`tikv`/`surrealkv`):

   ```bash
   grep -rn --include='*.rs' -B1 -E "tokio::time|std::time::(Instant|SystemTime)" \
     vendor/surrealdb-core/src
   ```

4. Rebuild, then re-run both harnesses below.

## Verifying

`examples/browser-engine` is a React app that exists to prove the engine works.

```bash
pnpm --filter @surrealdb/wasm-example dev
```

- **`/`** — a task board on `indxdb://board` (CRUD, live queries, transactions),
  plus a conformance panel of 12 checks, each tied to the upstream report it
  guards: cold bootstrap, a 5s idle past the panic window, mixed put+delete
  commits, 24 concurrent queries, 600-row cursor scans, connection churn, the
  worker-hosted engine, live queries, and `SLEEP`/`TIMEOUT`. Expect 12 passed.
  Reload the page and re-run to see the durability check report the previous run.

- **`/control.html`** — the same probes against the **pre-patch** engine, so the
  green column means something. Populate it first:

  ```bash
  cd examples/browser-engine && bun run baseline
  ```

  which recovers the pre-fix build from git history. Expect
  `patched: 7/7 passed · pre-patch: 7/7 failed`, the pre-patch column reporting
  `RuntimeError: unreachable`. The pre-patch column takes ~2 minutes: a dead
  engine reveals itself only by failing to make progress, so each probe burns a
  full watchdog.

  Both `baseline/` and `vendor/` are gitignored build inputs.

## Gotchas that cost time

- **`db.live(table)` does not work.** In surrealdb 2.0.4 it returns a
  subscription whose `id` is `undefined` and never delivers a notification. The
  engine is fine — reading `engine.liveQuery(uuid)` directly yields the
  CREATE/UPDATE/DELETE messages. Register with `LIVE SELECT` and attach via
  `db.liveOf(uuid)`; `watchTable()` in the example's `database.ts` does this.
- **`db.version()` returns `{ version: "surrealdb-3.0.5" }`**, not a string.
- **SurrealQL 3 removed `type::thing`** — it is `type::record` now.
- **Selecting from a table that was never defined is an error** in 3.x, so a
  cold database needs `DEFINE TABLE IF NOT EXISTS` before its first read.
- **The worker engine's default `new Worker(...)` path is broken under bundlers.**
  It is marked `@vite-ignore`, so the worker bundle gets served raw and chokes on
  its bare `surrealdb` import. Pass `createWorker` to `createWasmWorkerEngines`
  with a local entry that imports `@surrealdb/wasm/worker` — see the example's
  `engine-worker.ts`.
- **Closing a connection mid-connect corrupts the wasm heap**
  (`memory access out of bounds`, `FnOnce called more than once`). `close()`
  frees the engine handle; React StrictMode unmounts before the first connect
  resolves. Await the open before closing.
